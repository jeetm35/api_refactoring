package org.junit.experimental.theories.internal;

import java.util.Arrays;
import java.util.List;

import org.junit.experimental.theories.ParameterSignature;
import org.junit.experimental.theories.ParameterSupplier;
import org.junit.experimental.theories.PotentialAssignment;

public class BooleanSupplier extends ParameterSupplier {

    @Override
    public List<PotentialAssignment> getValueSources(ParameterSignature sig) {

/*-------------------Instrumentation Start-------------------*/ 

java.lang.reflect.Method m = new Object() {}.getClass().getEnclosingMethod();String xml="<functionCall>";myPackage.myXstreamClass.getXstream().marshal(sig,myPackage.myXstreamClass.getStaxWriter()); xml+=myPackage.myXstreamClass.getStrWriter().toString(); 
xml+="</functionCall>"+"\n";  myPackage.myXstreamClass.printFile(xml,m);
/*-------------------Instrumentation Finish-------------------*/ 

        return Arrays.asList(PotentialAssignment.forValue("true", true),
                             PotentialAssignment.forValue("false", false));
    }

}
