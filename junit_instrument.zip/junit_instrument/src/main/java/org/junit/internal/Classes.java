package org.junit.internal;

import static java.lang.Thread.currentThread;

/**
 * Miscellaneous functions dealing with classes.
 */
public class Classes {
    /**
     * Returns Class.forName for {@code className} using the current thread's class loader.
     *
     * @param className Name of the class.
     * @throws ClassNotFoundException
     */
    public static Class<?> getClass(String className) throws ClassNotFoundException {

/*-------------------Instrumentation Start-------------------*/ 

java.lang.reflect.Method m = new Object() {}.getClass().getEnclosingMethod();String xml="<functionCall>";myPackage.myXstreamClass.getXstream().marshal(className,myPackage.myXstreamClass.getStaxWriter()); xml+=myPackage.myXstreamClass.getStrWriter().toString(); 
xml+="</functionCall>"+"\n";  myPackage.myXstreamClass.printFile(xml,m);
/*-------------------Instrumentation Finish-------------------*/ 

        return Class.forName(className, true, currentThread().getContextClassLoader());
    }
}
