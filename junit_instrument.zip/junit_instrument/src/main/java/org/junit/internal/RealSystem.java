package org.junit.internal;

import java.io.PrintStream;

public class RealSystem implements JUnitSystem {

    /**
     * Will be removed in the next major release
     */
    @Deprecated
    public void exit(int code) {

/*-------------------Instrumentation Start-------------------*/ 

java.lang.reflect.Method m = new Object() {}.getClass().getEnclosingMethod();String xml="<functionCall>";myPackage.myXstreamClass.getXstream().marshal(code,myPackage.myXstreamClass.getStaxWriter()); xml+=myPackage.myXstreamClass.getStrWriter().toString(); 
xml+="</functionCall>"+"\n";  myPackage.myXstreamClass.printFile(xml,m);
/*-------------------Instrumentation Finish-------------------*/ 

        System.exit(code);
    }

    public PrintStream out() {
        return System.out;
    }

}
