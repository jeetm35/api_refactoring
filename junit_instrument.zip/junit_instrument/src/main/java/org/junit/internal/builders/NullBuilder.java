package org.junit.internal.builders;

import org.junit.runner.Runner;
import org.junit.runners.model.RunnerBuilder;

public class NullBuilder extends RunnerBuilder {
    @Override
    public Runner runnerForClass(Class<?> each) throws Throwable {

/*-------------------Instrumentation Start-------------------*/ 

java.lang.reflect.Method m = new Object() {}.getClass().getEnclosingMethod();String xml="<functionCall>";myPackage.myXstreamClass.getXstream().marshal(each,myPackage.myXstreamClass.getStaxWriter()); xml+=myPackage.myXstreamClass.getStrWriter().toString(); 
xml+="</functionCall>"+"\n";  myPackage.myXstreamClass.printFile(xml,m);
/*-------------------Instrumentation Finish-------------------*/ 

        return null;
    }
}