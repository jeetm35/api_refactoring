package junit.framework;

import org.junit.runner.Describable;
import org.junit.runner.Description;

public class JUnit4TestCaseFacade implements Test, Describable {
    private final Description fDescription;

    JUnit4TestCaseFacade(Description description) {
        fDescription = description;
    }

    @Override
    public String toString() {
        return getDescription().toString();
    }

    public int countTestCases() {
        return 1;
    }

    public void run(TestResult result) {

/*-------------------Instrumentation Start-------------------*/ 

java.lang.reflect.Method m = new Object() {}.getClass().getEnclosingMethod();String xml="<functionCall>";myPackage.myXstreamClass.getXstream().marshal(result,myPackage.myXstreamClass.getStaxWriter()); xml+=myPackage.myXstreamClass.getStrWriter().toString(); 
xml+="</functionCall>"+"\n";  myPackage.myXstreamClass.printFile(xml,m);
/*-------------------Instrumentation Finish-------------------*/ 

        throw new RuntimeException(
                "This test stub created only for informational purposes.");
    }

    public Description getDescription() {
        return fDescription;
    }
}