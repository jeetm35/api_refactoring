Change Log
==========

Version 1.1.0 *(2016-10-09)*
----------------------------

 * Expose a static method for creating the default `Cache`. This allows construction of
   your own `OkHttpClient` with whatever configuration while also retaining the default cache.


Version 1.0.2 *(2016-01-15)*
----------------------------

 * Update to OkHttp 3.0 final.


Version 1.0.1 *(2016-01-03)*
----------------------------

 * Add constructor overload for `Call.Factory`.


Version 1.0.0 *(2016-01-02)*
----------------------------

Initial version.
