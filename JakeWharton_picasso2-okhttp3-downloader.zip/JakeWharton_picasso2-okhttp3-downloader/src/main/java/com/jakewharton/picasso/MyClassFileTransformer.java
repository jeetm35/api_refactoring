package com.jakewharton.picasso;

import javassist.CannotCompileException;
import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.IllegalClassFormatException;
import java.security.ProtectionDomain;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtMethod;
import javassist.expr.ExprEditor;
import javassist.expr.MethodCall;
import java.io.*;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.sax.SAXTransformerFactory;
import javax.xml.transform.stream.StreamResult;
import org.xml.sax.InputSource;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;

 
public class MyClassFileTransformer implements ClassFileTransformer {
 
    public byte[] transform(ClassLoader loader, String className, Class classBeingRedefined,
        ProtectionDomain protectionDomain, byte[] classfileBuffer) throws IllegalClassFormatException {
        byte[] byteCode = classfileBuffer;
        if (className.equals("org/junit/Assert")) {
        	System.out.println("Found class!");
            try {
            	System.out.println("Beginning to instrument!!!");
                ClassPool cp = ClassPool.getDefault(); 
                CtClass cc = cp.get("org.junit.Assert");
				CtMethod[] methods = cc.getDeclaredMethods();
				
				for(CtMethod m:methods) {
					String name = m.getName();
					String signature = m.getSignature();
					CtClass[] pTypes = m.getParameterTypes();
					String in ="System.out.println(\"Method " + name + " " +signature+" executed\" );";
					signature = signature.substring(1);
					System.out.println("substring signature="+signature);
					int pos = signature.indexOf(')');
					String newSignature=signature.substring(0,pos)+'_'+signature.substring(pos+1);
					newSignature=newSignature.replaceAll("/", ".");
					System.out.println(newSignature);
					in+="java.lang.String path = \"/mnt/c/Sneha/Studies/UCLA/Classes/Q3Spring2018/CS230/Project/api-refactoring/api_refactoring/InstrumentationResults/serialize_"+cc.getName()+"."+name+"."+newSignature+".txt\";";
					
					in+= "java.io.File file = new java.io.File(path);";
					in+="java.io.FileWriter fw = new java.io.FileWriter(file.getAbsoluteFile(),true);";
					in+="java.io.BufferedWriter bw = new java.io.BufferedWriter(fw);";
					
					
					in+="com.thoughtworks.xstream.XStream xs = new com.thoughtworks.xstream.XStream(new com.thoughtworks.xstream.io.xml.StaxDriver());";
					in+="java.lang.String xml;";
					in+="java.lang.String completeXML=\"<functionCall>\";";
					in+="com.thoughtworks.xstream.io.xml.StaxDriver drv = new com.thoughtworks.xstream.io.xml.StaxDriver();";
	            	in+="com.thoughtworks.xstream.XStream xstream = new com.thoughtworks.xstream.XStream();";
	            	in+="java.io.StringWriter strWriter = new java.io.StringWriter();";
	            	in+="com.thoughtworks.xstream.io.xml.StaxWriter sw = new com.thoughtworks.xstream.io.xml.StaxWriter(drv.getQnameMap(), drv.getOutputFactory().createXMLStreamWriter(strWriter), false, true);";
	            	
				
					//Serialize each argument
					for( int i=0; i < pTypes.length; ++i ) {
						CtClass pType = pTypes[i];
	                    in+="xstream.marshal($args[" + i + "],sw);";
	                    in+="xml=strWriter.toString();";
						in+="completeXML+=xml;";
					}
					in+="completeXML+=\"</functionCall>\\n\";";
					in+="System.out.println(\"************ Printing complete xml ************\");";
					in+="System.out.println(completeXML);";
					
					in+="bw.write(completeXML);";
					in+="bw.close();";
                m.insertAfter("{" + in + "}");
					
				}

                byteCode = cc.toBytecode();
                cc.detach();
                System.out.println("Finished instrumenting!!!");
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        
 
        return byteCode;
    }
}
